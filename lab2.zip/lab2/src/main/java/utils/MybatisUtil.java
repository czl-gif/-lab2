package utils;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import java.io.IOException;
import java.io.InputStream;
import javax.annotation.Resource;

public class MybatisUtil {
    private static SqlSessionFactory sqlSessionFactory;
    static {
        //获取sqlSessionFatory对象
        try {
            String resource = "mybatis-config.xml";
            InputStream is = Resources.getResourceAsStream(resource);
            sqlSessionFactory = new SqlSessionFactoryBuilder().build(is);
        }catch (IOException e) {
            e.printStackTrace();
        }
    }
    //从sqlSessionFactory中获得SqlSession的实例了。
    //SqlSession完全包含了面向数据库执行SQL命令所需的所有方法
    public static SqlSession getSqlSession(){
        return sqlSessionFactory.openSession();
    }
}
