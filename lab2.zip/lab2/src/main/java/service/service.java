package service;

import POJO.Person;
import POJO.User;

import java.util.List;

public interface service {
    public boolean addPerson(Person person);

    public boolean addUser(User user);

    public boolean findUser(String username);

    public boolean findPerson(String username);

    public boolean updatePerson(Person person);

    public String removePerson(String username);

    public String removeUser(String username);

    public List<Person> getPersonList();

    public List<User> getUserList();
}
