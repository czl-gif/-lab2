package service;

import DAO.PersonDAO;
import DAO.UserDAO;
import org.apache.ibatis.session.SqlSession;
import POJO.Person;
import POJO.User;
import utils.MybatisUtil;

import java.util.ArrayList;
import java.util.List;

public class servicelmp implements service {
    @Override
    public boolean addPerson(Person person) {
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        PersonDAO personDAO = sqlSession.getMapper(PersonDAO.class);

        int i = personDAO.addPerson(person);
        if(i > 0) {
            System.out.println("succeed");
            sqlSession.commit();//事务的提交
        }

        sqlSession.close();
        return i > 0 ? true : false;
    }

    @Override
    public boolean addUser(User user) {
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        UserDAO userDAO = sqlSession.getMapper(UserDAO.class);

        int i = userDAO.addUser(user);
        if (i > 0) {
            sqlSession.commit();
        }
        sqlSession.close();
        return i > 0 ? true : false;
    }

    @Override
    public  boolean updatePerson(Person person) {
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        PersonDAO personDAO = sqlSession.getMapper(PersonDAO.class);

        int i = personDAO.updatePerson(person);
        if (i > 0) {
            sqlSession.commit();
        }
        sqlSession.close();
        return i > 0 ? true : false;
    }

    @Override
    public boolean findUser(String username) {
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        UserDAO userDAO = sqlSession.getMapper(UserDAO.class);

        boolean flag = false;
        List<User> userList = userDAO.getUserList();
        for (User user: userList) {
            if(user.getUsername().equals(username)) {
                flag = true;
                break;
            }
        }
        return flag;
    }

    @Override
    public boolean findPerson(String username) {
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        PersonDAO personDAO = sqlSession.getMapper(PersonDAO.class);

        boolean flag = false;
        List<Person> personList = personDAO.getPersonList();
        for (Person person: personList) {
            if(person.getUsername().equals(username)){
                flag = true;
                break;
            }
        }
        return flag;
    }

    @Override
    public String removePerson(String username) {
        String info = "成功删除person表中的用户" + username;
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        PersonDAO personDAO = sqlSession.getMapper(PersonDAO.class);

        //判断数据库中是否有该username
        boolean flag = false;
        List<Person> personList = personDAO.getPersonList();
        for (Person person: personList) {
            if (person.getUsername().equals(username)){
                flag = true;
                break;
            }
        }
        if (flag) {
            int i = personDAO.removePerson(username);
            if(i > 0) {
                sqlSession.commit();
            }
        }else{
            info = "person表中不存在" + username;
        }
        sqlSession.close();
        return info;
    }
    @Override
    public  String removeUser(String username) {
        String info = "成功删除user表中的用户" + username;
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        UserDAO userDAO = sqlSession.getMapper(UserDAO.class);
        //判断数据库中是否有该username
        boolean flag = false;
        List<User> userList = userDAO.getUserList();
        for (User user:userList) {
            if (user.getUsername().equals(username)){
                flag = true;
                break;
            }
        }
        if(flag) {
            int i = userDAO.removeUser(username);
            if(i > 0) {
                sqlSession.commit();
            }
        }else{
            info = "user表中不存在" + username;
        }
        sqlSession.close();
        return info;
    }

    @Override
    public List<Person> getPersonList() {
        List<Person> personList = null;
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        PersonDAO personDAO = sqlSession.getMapper(PersonDAO.class);

        personList = personDAO.getPersonList();

        sqlSession.close();
        return personList;
    }

    @Override
    public List<User> getUserList() {
        List<User> userList = null;
        SqlSession sqlSession = MybatisUtil.getSqlSession();
        UserDAO userDAO = sqlSession.getMapper(UserDAO.class);

        userList = userDAO.getUserList();

        sqlSession.close();
        return userList;
    }
}
