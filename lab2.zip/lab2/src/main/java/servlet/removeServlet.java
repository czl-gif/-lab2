package servlet;

import service.service;
import service.servicelmp;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "removeServlet")
public class removeServlet extends HttpServlet {
    private service server = new servicelmp();

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws
            ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        response.setCharacterEncoding("utf-8");

        //默认删除person和user表中等于username的数据
        String username = request.getParameter("username2");
        server.removePerson(username);
        String info = server.removeUser(username);

        request.getSession().setAttribute("info", info);
        response.sendRedirect("printResult.jsp");
    }
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws
            ServletException, IOException {
        doPost(request, response);
    }
}

