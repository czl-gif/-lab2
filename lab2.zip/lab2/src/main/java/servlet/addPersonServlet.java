package servlet;

import POJO.Person;
import POJO.User;
import service.service;
import service.servicelmp;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "addPersonServlet")
public class addPersonServlet extends HttpServlet{
    private service server = new servicelmp();

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws
            ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        response.setCharacterEncoding("utf-8");

        String username = request.getParameter("username");
        String name = request.getParameter("name");
        String S_age = request.getParameter("age");
        Integer age;
        if(S_age !="")
            age = Integer.parseInt(S_age);
        else age = null;
        String telenum = request.getParameter("telenum");

        Person person = new Person(username, name, age, telenum);

        User user = new User(username, "888888");
        boolean flag1 = false;
        boolean flag3 = false;
        if(! server.findPerson(username))
            flag1 = server.addPerson(person);
        else
            flag3 = server.updatePerson(person);
        boolean flag2 = true;
        if (! server.findUser(username))
            flag2 = server.addUser(user);

        if(flag1) {
            request.getSession().setAttribute("info", "成功插入person " + username);
            response.sendRedirect("printResult.jsp");
        }
        else if (flag3) {
            request.getSession().setAttribute("info", "成功更新person " + username);
            response.sendRedirect("printResult.jsp");
        }
        else {
            request.getSession().setAttribute("errInfo", "请重新插入person信息");
            response.sendRedirect("index.jsp");
        }
    }
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws
            ServletException, IOException {
        doPost(request, response);
    }
}
